import $ from 'jquery';

window.$ = $;
window.jQuery = $;