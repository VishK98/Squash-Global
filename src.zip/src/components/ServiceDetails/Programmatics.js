import React from 'react'

function Programmatics() {
  return (
    <div>Programmatics</div>
  )
}

export default Programmatics