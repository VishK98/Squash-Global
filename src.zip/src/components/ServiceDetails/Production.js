import React from 'react'

function Production() {
  return (
    <div>Production</div>
  )
}

export default Production