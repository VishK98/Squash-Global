import React from 'react'

function Influencer() {
  return (
    <div>Influencer</div>
  )
}

export default Influencer