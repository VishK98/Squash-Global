import React from 'react'

function SocialMedia() {
  return (
    <div>SocialMedia</div>
  )
}

export default SocialMedia