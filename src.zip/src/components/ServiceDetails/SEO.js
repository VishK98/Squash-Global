import React from 'react'

function SEO() {
  return (
    <div>SEO</div>
  )
}

export default SEO