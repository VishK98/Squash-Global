import React from 'react'

function Creative() {
  return (
    <div>Creative</div>
  )
}

export default Creative